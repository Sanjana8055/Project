import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LocalStorageService } from '../local-storage.service';
import { ProjService } from '../proj.service';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {
  newBooks:any;
  bookName:any;
  searchedBook:any;
  constructor(private router: Router, private local:LocalStorageService, private service:ProjService) { }

  ngOnInit(): void {
    this.service.getNewBooks().subscribe((result:any)=>{console.log(result); this.newBooks = result;} )
  }
  callLogOut() {
    this.local.logout();
    this.router.navigate(['login']);
  }
  routeTosellBook() {
    this.local.logout();
    this.router.navigate(['sell-book']);
  }
  routeToViewCustomers() {
    this.router.navigate(['show-customers']);
  }
  routeToViewAllOrders() {
    this.router.navigate(['view-all-orders']);
  }
  searchBook(bookName: any) {
    this.bookName = bookName;
    this.service.searchBook(bookName).subscribe((result:any)=>{console.log(result); this.searchedBook = result; console.log(this.searchedBook);});
  }
  callHome() {
    this.router.navigate(['homepage']);
  }
  update(quantity: any, bookId:any) {
    this.service.updateBook(quantity, bookId).subscribe();
  }
}
