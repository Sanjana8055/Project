import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Pipe, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { BooksComponent } from './books/books.component';

import { SellBookComponent } from './sell-book/sell-book.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { ShowCustomersComponent } from './show-customers/show-customers.component';
import { MobilePipe } from './mobile.pipe';
import { CartComponent } from './cart/cart.component';
import { MyBooksComponent } from './my-books/my-books.component';
import { ViewAllOrdersComponent } from './view-all-orders/view-all-orders.component';
import { HomepageComponent } from './homepage/homepage.component';
import {SocialComponent } from './social/social.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 
import { ToastrModule } from 'ngx-toastr';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { ReviewComponent } from './review/review.component';
import { ShowReviewsComponent } from './show-reviews/show-reviews.component';
import { HelpComponent } from './help/help.component';
import { MailComponent } from './mail/mail.component';
 


const appRoot: Routes = [{ path: '', component: HomepageComponent },
{path:'homepage', component: HomepageComponent},
{ path: 'login', component: LoginComponent },
{ path: 'register', component: RegisterComponent },
{ path: 'books', component: BooksComponent },
{ path: 'admin-page', component: AdminPageComponent },
{ path: 'show-customers', component: ShowCustomersComponent },
{ path: 'sell-book', component: SellBookComponent },
{ path: 'cart', component: CartComponent },
{ path: 'my-books', component: MyBooksComponent },
{ path: 'view-all-orders', component: ViewAllOrdersComponent },
{ path: 'social', component: SocialComponent },
{ path: 'order-history', component: OrderHistoryComponent},
{ path: 'review', component: ReviewComponent},
{ path: 'show-reviews', component: ShowReviewsComponent},
{ path: 'help', component: HelpComponent},
{ path: 'mail', component: MailComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    RegisterComponent,
    BooksComponent,
    SellBookComponent,
    AdminPageComponent,
    ShowCustomersComponent,
    MobilePipe,
    CartComponent,
    MyBooksComponent,
    ViewAllOrdersComponent,
    HomepageComponent,
    SocialComponent,
    OrderHistoryComponent,
    ReviewComponent,
    ShowReviewsComponent,
    HelpComponent,
    MailComponent
    


  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule, HttpClientModule, RouterModule.forRoot(appRoot),

    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot(), // ToastrModule added



    
  ],
  providers: [MailComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
