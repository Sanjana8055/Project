import { Component, OnInit } from '@angular/core';
import { ProjService } from '../proj.service';
import { LoginComponent } from '../login/login.component';
import { LocalStorageService } from '../local-storage.service';
import { ConvertActionBindingResult } from '@angular/compiler/src/compiler_util/expression_converter';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
declare var jQuery:any;
declare var webkitSpeechRecognition;



@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  books: any
  editObject:any
  customer:any
  address:any
  bookName: any;
  searchedBook: any;
  oldBooks: any;
  newBooks: any;
  reviewsList:any;


  constructor(private service: ProjService, private local:LocalStorageService, private router: Router, private toastr: ToastrService) {
    this.address={state:'', street:'', city:'', houseNo:'', pincode:''}
    this.editObject={custId: '', custName: '', email: '', mobileNo:'', loginId: '', password:'',address: this.address}
   }


  ngOnInit() {
    this.customer=JSON.parse(this.local.getLocal());
    this.service.getOldBooks(this.customer.custId).subscribe((result:any)=>{console.log(result); this.oldBooks = result;});
    this.service.getNewBooks().subscribe((result:any)=>{console.log(result); this.newBooks = result;} )
  }

  showEditPopup(){
    this.editObject = this.customer;
    console.log(this.editObject);
    jQuery('#custModel').modal('show');
  }
  updateCust() {
    this.service.updateCust(this.editObject).subscribe();
    console.log(this.editObject)
  }
  callLogOut() {
    this.router.navigate(['login']);
  }
  routeTosellBook() {
    this.router.navigate(['sell-book']);
  }
  routeToViewMyCart() {
    this.router.navigate(['cart']);
  }
  routeToBooksAddedByMe() {
    this.router.navigate(['my-books']);
  }
  routeToMyOrders() {
    this.router.navigate(['order-history']);
  }
  routeToHelp() {
    this.router.navigate(['help']);
  }

  handleAddToCart(book: any) {
    const i = this.books.findIndex((element)=>{return element.bookId === book.bookId;});
   // this.service.addToCart(this.customer.custId,this.books[i].bookId).subscribe((result:any)=>console.log(result));
  }

  handleAddToCart1(book: any, quantity: any) {
    const i = this.oldBooks.findIndex((element)=>{return element.bookId === book.bookId;});
    this.service.addToCart(this.customer.custId,this.oldBooks[i].bookId, quantity).subscribe((result:any)=>console.log(result));
    this.toastr.success('Item added to cart successfully!', 'Cart');
  }

  handleAddToCart2(book: any, quantity: any) {
    const i = this.newBooks.findIndex((element)=>{return element.bookId === book.bookId;});
    this.service.addToCart(this.customer.custId,this.newBooks[i].bookId, quantity).subscribe((result:any)=>console.log(result));
    this.toastr.success('Item added to cart successfully!', 'Cart');
  }
 
  searchBook(bookName: any) {
    this.bookName = bookName;
    this.service.searchBook(bookName).subscribe((result:any)=>{console.log(result); this.searchedBook = result; console.log(this.searchedBook);});
  }

  callHome() {
    this.router.navigate(['homepage']);
  }


  public voiceSearch() {
    
    const searchForm = document.querySelector("#search-form");
    const searchformInput = searchForm.querySelector("input");
    const SpeechRecognition = window.SpeechRecognition || 'webkitSpeechRecognition' in window; 
    if(SpeechRecognition) {
      console.log("Browser supports");
      const micBtn = searchForm.querySelector("button");
      const micIcon = micBtn.querySelector("i");
      var recognition = new webkitSpeechRecognition();
      recognition.continuous = true;
      micBtn.addEventListener("click", micBtnClick);
      function micBtnClick() {
        if(micIcon.classList.contains("fa-microphone")) {
          micIcon.classList.remove("fa-microphone");
          micIcon.classList.add("fa-microphone-slash");
          recognition.start();

        }
        else {
          micIcon.classList.remove("fa-microphone-slash");
          micIcon.classList.add("fa-microphone");
          recognition.stop();
        }
      }
      function searchBook(bookName: any) {
        this.bookName = bookName;
        this.service.searchBook(bookName).subscribe((result:any)=>{console.log(result); this.searchedBook = result; console.log(this.searchedBook);});
      }
      recognition.addEventListener("start", startSpeechRecognition);
      function startSpeechRecognition() {
        console.log("Speech Recoginition active");
        micIcon.classList.remove("fa-microphone");
        micIcon.classList.add("fa-microphone-slash");
        searchformInput.focus();
      }
      recognition.addEventListener("end", endSpeechrecognition);
      function endSpeechrecognition() {
        console.log("Speech Recognition Disconnected");
        micIcon.classList.remove("fa-microphone-slash");
        micIcon.classList.add("fa-microphone");
        searchformInput.focus();
      }

      recognition.addEventListener("result", resultOfSpeechRecognition);
      function resultOfSpeechRecognition(event) {
        const transcript = event.results[0][0].transcript;
        searchformInput.value = transcript;
        this.bookName = searchformInput.value 
        console.log(this.bookName);
        
        //searchBook(searchformInput.value);

       
      }
     // this.service.searchBook(searchformInput.value).subscribe((result:any)=>{console.log(result); this.searchedBook = result; console.log(this.searchedBook);});


    }
    else {
      console.log("Browser not supports");
    }
  }

  callShowReviews(book:any){
    localStorage.setItem('book',JSON.stringify(book));
      this.router.navigate(['show-reviews']);
  }

}





 