import { Component, OnInit } from '@angular/core';
import { ProjService } from '../proj.service';
import { LocalStorageService } from '../local-storage.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
declare var jQuery:any;

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartTotal = 0;
  address:any;
  editObject:any;
  constructor(private service: ProjService, private local:LocalStorageService, private router: Router, private toastr: ToastrService) {
    this.address={state:'', street:'', city:'', houseNo:'', pincode:''}
    this.editObject={custId: '', custName: '', email: '', mobileNo:'', loginId: '', password:'',address: this.address}
   }
  customer: any;
  cartItems: any;
 
  ngOnInit(): void {
    this.customer = JSON.parse(this.local.getLocal());
    this.service.viewMyCart(this.customer.custId).subscribe((result: any) => {
      this.cartItems = result; console.log(this.cartItems);

      this.cartItems.forEach(element => {
        this.cartTotal += (element.cartQuantity * element.price)
      });

      console.log("cartTotal" + this.cartTotal);


    });


  }
  placeOrder(custId: any) {
    this.service.placeOrder(custId).subscribe((result: any) => { console.log(result) });
    this.toastr.success('Order Placed Successfully', 'Place Order');
          
  }

  removeFromCart(cartItem: any) {
    console.log("i"+cartItem.cartId)
    this.service.removeFromCart(cartItem.cartId).subscribe((result: any) => {
      const i = this.cartItems.findIndex((element) => {
        return element.bookName === cartItem.bookName;
      });
      console.log("i" + i);
      this.cartItems.splice(i, 1);
    });
  }






  showEditPopup(){
    this.editObject = this.customer;
    console.log(this.editObject);
    jQuery('#custModel').modal('show');
  }
  updateCust() {
    this.service.updateCust(this.editObject).subscribe();
    console.log(this.editObject)
  }
  callLogOut() {
    this.router.navigate(['login']);
  }
  routeTosellBook() {
    this.router.navigate(['sell-book']);
  }
  routeToViewMyCart() {
    this.router.navigate(['cart']);
  }
  routeToBooksAddedByMe() {
    this.router.navigate(['my-books']);
  }
  routeToMyOrders() {
    this.router.navigate(['order-history']);
  }
  callHome() {
    this.router.navigate(['homepage']);
  }

  

}


/*
this.cartItems.forEach(element => {
      console.log("qty1"+ element.quantity);
      console.log(element.price);
      this.cartTotal += (element.quantity * element.price)
    });
    update(quantity: any, bookId: any) {
    this.service.updateCartQuantity(bookId, quantity, this.customer.custId).subscribe((result: any) => { console.log("qty " + result); });
  }
    
    */