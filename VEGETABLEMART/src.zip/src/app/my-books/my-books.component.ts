import { Component, OnInit } from '@angular/core';
import { ProjService } from '../proj.service';
import { LocalStorageService } from '../local-storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-books',
  templateUrl: './my-books.component.html',
  styleUrls: ['./my-books.component.css']
})
export class MyBooksComponent implements OnInit {
  customer:any;
  myBooks:any;
  constructor(private service: ProjService, private local: LocalStorageService, private router: Router) { }

  ngOnInit(): void {
    this.customer = JSON.parse(this.local.getLocal());
    //console.log(this.customer.custId);
    this.service.viewMyBooksAdded(this.customer.custId).subscribe((result:any)=> {console.log(result); this.myBooks = result;});
  }
  deleteMyBook(book: any) {
    this.service.deleteMyBook(book).subscribe((result: any) => {
      const i = this.myBooks.findIndex((element) => {return element.bookId === book.bookId;
          });
      this.myBooks.splice(i , 1);
        });
  }
  callLogOut() {
    this.router.navigate(['login']);
  }
  routeTosellBook() {
    this.router.navigate(['sell-book']);
  }
  routeToViewMyCart() {
    this.router.navigate(['cart']);
  }
  routeToBooksAddedByMe() {
    this.router.navigate(['my-books']);
  }
  routeToMyOrders() {
    this.router.navigate(['order-history']);
  }
}
