import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../local-storage.service';
import { ProjService } from '../proj.service';
import { Router } from '@angular/router';

declare var jQuery:any;

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  customer: any;
  orders: any;
  order: any;
  orderCount:any;
  bookId:any
  review:any
  reviews:any
  constructor(private local: LocalStorageService, private service: ProjService, private router:Router) { 
    this.reviews={books:'', customer:'', review:''}
  }

  ngOnInit(): void {
    this.customer = JSON.parse(this.local.getLocal());
    console.log(this.customer.custId);
    this.service.viewMyOrders(this.customer.custId).subscribe((result: any) => {
      this.orders = result;
    });
    this.service.viewCountOfOrders(this.customer.custId).subscribe((result: any) => {console.log(result); this.orderCount = result; console.log(this.orderCount[0][0])});
  }
  callreview(book:any){
    localStorage.setItem('book',JSON.stringify(book));
    this.router.navigate(['review']);
  }

  showEditPopup(book:any){
    localStorage.setItem('book',JSON.stringify(book));
    jQuery('#reviewModel').modal('show');
  }

  reviewSubmit(review: any) {
    this.reviews.books =JSON.parse(localStorage.getItem('book'));
    this.reviews.customer = JSON.parse(this.local.getLocal());
    this.reviews.review = review;
    console.log(this.reviews);
  
    this.service.addReview(this.reviews).subscribe();

  }
  callLogOut() {
    this.router.navigate(['login']);
  }
  routeTosellBook() {
    this.router.navigate(['sell-book']);
  }
  routeToViewMyCart() {
    this.router.navigate(['cart']);
  }
  routeToBooksAddedByMe() {
    this.router.navigate(['my-books']);
  }
  routeToMyOrders() {
    this.router.navigate(['order-history']);
  }


}



    /* this.local.setLocalOrders(JSON.stringify(result));
       this.orders = JSON.parse(this.local.getLocalOrders());
    
    for (let order of this.orders) {
       if (!(order.orderId in this.orderIds)) {
         this.orderIds.push.apply(order.orderId);
       }
     }*/



