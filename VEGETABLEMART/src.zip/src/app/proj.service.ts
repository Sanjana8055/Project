import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProjService {
 
  custId = 0;
  loginId: any;
 
  constructor(private httpClient: HttpClient) {
   

  }
  getAllLoginIds(){
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getAllLoginIds');

  }


  regCustomer(customer: any) {
    customer.custId = this.custId++;
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/regCustomer/', customer);
  }

  customerLogin(loginId: any, password: any) {
    console.log(loginId, password)
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/customerLogin/' + loginId + "/" + password);
  }

  getAllCustomers() {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewAllCustomers');
  }
  getAllBooks() {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewAllBooks');
  }
  addToCart(custId: any, bookId: any, quantity: any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/addItemToCart/' + custId + "/" + bookId + "/" + quantity);
  }
  viewMyCart(custId: any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewMyCart/' + custId);
  }
  placeOrder(custId: any) {
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/placeOrder/', custId);
  }
  viewMyBooksAdded(custId: any) {
    console.log(custId);
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewMyBooks/' + custId);
  }
  postFile(sellForm: any, fileToUpload: File) {
    const endpoint = 'RESTAPI2018/webapi/myresource1/uploadImage';
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('bookName', sellForm.bookName);
    formData.append('description', sellForm.description);
    formData.append('price', sellForm.price);
    formData.append('bookStatus', sellForm.bookStatus);
    formData.append('category', sellForm.category);
    formData.append('quantityAdded', sellForm.quantityAdded);
    // formData.append('publishedDate', sellForm.publishedDate);
    formData.append('custId', sellForm.custId);

    return this.httpClient.post(endpoint, formData);
  }

  updateCust(customer: any) {
    return this.httpClient.put('RESTAPI2018/webapi/myresource1/updateCustomer/', customer);
  }
  deleteMyBook(book: any) {
    return this.httpClient.delete('RESTAPI2018/webapi/myresource1/deleteMyBookAdded/' + book.bookId);
  }

  getBookById(bookId: any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getBookById/' + bookId);
  }
  searchBook(bookName: any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/searchBook/'+ bookName);
  }
  deliverOrder(orderId: any) {
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/deliverOrder/', orderId);
  }
  viewAllOrders() {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewAllOrders');
  }

  getOldBooks(custId: any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getOldBooks/' + custId);
  }

  getNewBooks() {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getNewBooks');
  }

  removeFromCart(cartId: any) {
    return this.httpClient.delete('RESTAPI2018/webapi/myresource1/removeFromCart/' + cartId);
  }
  deliverOrders() {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/deliverOrders');
  }
  viewMyOrders(custId:any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewMyOrders/'+custId);
  }
  viewCountOfOrders(custId:any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/viewCountOfOrders/'+custId);
  }
  updateBook(quantity: any, bookId: any) {
    console.log(quantity, bookId)
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/updateBook/'+bookId+"/"+ quantity);
  }
  addReview(review:any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/addReview/', review);
  }

  getReviewsBybookId(bookId:any){
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getReviewsByBookId/'+bookId);

  }
 
}
