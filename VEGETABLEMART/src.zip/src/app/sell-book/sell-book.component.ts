import { Component, OnInit } from '@angular/core';
import { ProjService } from '../proj.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { LocalStorageService } from '../local-storage.service';

@Component({
  selector: 'app-sell-book',
  templateUrl: './sell-book.component.html',
  styleUrls: ['./sell-book.component.css']
})
export class SellBookComponent implements OnInit {
  imageUrl: String;
  fileToUpload: File = null;
  reader: FileReader;
  books: any;
  customer: any;
  custId: any;
  constructor(private service: ProjService, private local: LocalStorageService) {

    this.imageUrl = '/assets/images/default.png';
    this.books = { bookId: '', bookName: '', description: '', bookStatus: '', category: '', publishedDate: '', quantityAdded: '', price: '', imageName: '', custId: '' };

  }

  ngOnInit(): void {
    this.customer = JSON.parse(this.local.getLocal());
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(sellForm: any) {
    if (this.customer == null) {
      this.books.bookStatus = "new";
      sellForm.bookStatus = this.books.bookStatus;
      sellForm.custId = 0;
    }
    else {
      this.books.bookStatus = "old";
      sellForm.quantityAdded = 1;
      sellForm.bookStatus = this.books.bookStatus;
      sellForm.custId = this.customer.custId;
    }
    this.service.postFile(sellForm, this.fileToUpload).subscribe(data => {
      console.log('done');
      this.imageUrl = '/assets/images/default.png';
    });
  }

}
