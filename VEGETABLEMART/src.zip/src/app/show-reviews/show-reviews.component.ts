
import { Component, OnInit } from '@angular/core';
import { ProjService } from '../proj.service';

@Component({
  selector: 'app-show-reviews',
  templateUrl: './show-reviews.component.html',
  styleUrls: ['./show-reviews.component.css']
})
export class ShowReviewsComponent implements OnInit {
 book:any
 reviewsList:any
  constructor(private service:ProjService) { }

  ngOnInit(): void {
    this.book = JSON.parse(localStorage.getItem("book"));
    this.service.getReviewsBybookId(this.book.bookId).subscribe((result:any) => {this.reviewsList = result;console.log(result)});
  }

}
